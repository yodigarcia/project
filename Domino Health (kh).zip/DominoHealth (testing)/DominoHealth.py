from flask import Flask, render_template

app = Flask(__name__)


@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/tracker')
def tracker():
    return render_template('tracker.html')

@app.route('/food')
def food():
    return render_template('food.html')

@app.route('/database')
def database():
    return render_template('database.html')

@app.route('/wiki')
def wiki():
    return render_template('wiki.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/chronic_illness')
def chronic_illness():
    return render_template('chronic_illness.html')

if __name__ == '__main__':
    app.run(debug=True)
